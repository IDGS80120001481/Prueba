﻿namespace Lignaris.DTO
{
    public class ProveedorDTO
    {
        public int IdProveedor { get; set; }
        public int Estatus { get; set; }
        public PersonaDTO? Persona { get; set; }
    }
}
