﻿namespace LignarisBack.Dto
{
    public class RoleResponseDto
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public int TotalUsers { get; set; }
    }
}
