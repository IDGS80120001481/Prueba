﻿namespace Lignaris.DTO
{
    public class MateriaPrimaDTO
    {
        public int IdMateriaPrima { get; set; }
        public string? Nombre { get; set; }
        public string? TipoMedida { get; set; }
        public decimal? CantidadMinima { get; set; }
    }
}
