﻿namespace Lignaris.DTO
{
    public class RecetaDetalleDTO
    {
        public int IdRecetaDetalle { get; set; }
        public int IdMateriaPrima { get; set; }
        public decimal? Cantidad { get; set; }
    }
}
