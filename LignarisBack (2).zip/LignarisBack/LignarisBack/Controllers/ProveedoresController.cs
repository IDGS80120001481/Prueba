﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Lignaris.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Lignaris.DTO;

namespace Lignarias.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProveedoresController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProveedoresController(AppDbContext context)
        {
            _context = context;
        }

        // Método GET para obtener la lista de ProveedorMateriaPrima
        [HttpGet]
        [Route("ProveedoresMateriaPrima")]
        public async Task<ActionResult<IEnumerable<ProveedorMateriaPrimaDTO>>> GetProveedoresMateriaPrima()
        {
            var proveedores = await _context.Proveedores
                .Select(p => new ProveedorMateriaPrimaDTO
                {
                    IdProveedor = p.IdProveedor,
                    Nombre = p.Persona.Nombre,
                    ApellidoPaterno = p.Persona.ApellidoPaterno,
                    ApellidoMaterno = p.Persona.ApellidoMaterno
                })
                .ToListAsync();

            return Ok(proveedores);
        }

        // GET: api/Proveedores/ConMateriasPrimas
        [HttpGet]
        [Route("ConMateriasPrimas")]
        public async Task<ActionResult<IEnumerable<object>>> GetProveedoresConMateriasPrimas()
        {
            var proveedores = await _context.Proveedores
                .Include(p => p.Persona)
                .Include(p => p.MateriasPrimas)
                .Select(p => new
                {
                    p.IdProveedor,
                    p.Estatus,
                    Persona = new
                    {
                        p.Persona.IdPersona,
                        p.Persona.Nombre,
                        p.Persona.ApellidoPaterno,
                        p.Persona.ApellidoMaterno,
                        p.Persona.Telefono,
                        p.Persona.Direccion,
                        p.Persona.Email
                    },
                    MateriasPrimas = p.MateriasPrimas.Select(mp => new
                    {
                        mp.IdMateriaPrima,
                        mp.Nombre,
                        mp.TipoMedida,
                        mp.CantidadMinima,
                        mp.IdProveedor
                    })
                })
                .ToListAsync();

            return Ok(proveedores);
        }

    // GET: api/Proveedores
    [HttpGet]
        [Route("ListaProveedores")]
        public async Task<ActionResult<IEnumerable<object>>> GetProveedores()
        {
            var proveedores = await _context.Proveedores
                .Include(p => p.Persona)
                .Select(p => new
                {
                    p.IdProveedor,
                    p.Estatus,
                    Persona = new
                    {
                        p.Persona.IdPersona,
                        p.Persona.Nombre,
                        p.Persona.ApellidoPaterno,
                        p.Persona.ApellidoMaterno,
                        p.Persona.Telefono,
                        p.Persona.Direccion,
                        p.Persona.Email
                    }
                })
                .ToListAsync();

            return Ok(proveedores);
        }

        // GET: api/Proveedores/id
        [HttpGet]
        [Route("ListaProveedores/{id:int}")]
        public async Task<ActionResult<Proveedor>> GetProveedor(int id)
        {
            var proveedor = await _context.Proveedores
                .Include(p => p.Persona)
                .Include(p => p.MateriasPrimas)
                .FirstOrDefaultAsync(p => p.IdProveedor == id);

            if (proveedor == null)
            {
                return NotFound();
            }

            return proveedor;
        }

        // POST: api/Proveedores
        [HttpPost]
        [Route("AgregarProveedor")]
        public async Task<ActionResult<Proveedor>> PostProveedor(ProveedorDTO proveedorDTO)
        {
            var persona = new Persona
            {
                Nombre = proveedorDTO.Persona.Nombre,
                ApellidoPaterno = proveedorDTO.Persona.ApellidoPaterno,
                ApellidoMaterno = proveedorDTO.Persona.ApellidoMaterno,
                Telefono = proveedorDTO.Persona.Telefono,
                Direccion = proveedorDTO.Persona.Direccion,
                Email = proveedorDTO.Persona.Email
            };

            _context.Personas.Add(persona);
            await _context.SaveChangesAsync();

            var proveedor = new Proveedor
            {
                Estatus = proveedorDTO.Estatus,
                IdPersona = persona.IdPersona
            };

            _context.Proveedores.Add(proveedor);
            await _context.SaveChangesAsync();

            var newProveedor = await _context.Proveedores
                .Include(p => p.Persona)
                .FirstOrDefaultAsync(p => p.IdProveedor == proveedor.IdProveedor);

            return CreatedAtAction("GetProveedor", new { id = proveedor.IdProveedor }, newProveedor);
        }

        // PUT: api/Proveedores/id
        [HttpPut]
        [Route("ModificarProveedor/{id:int}")]
        public async Task<IActionResult> PutProveedor(int id, ProveedorDTO proveedorUpdateDto)
        {
            if (id != proveedorUpdateDto.IdProveedor)
            {
                return BadRequest();
            }

            var proveedor = await _context.Proveedores
                .Include(p => p.Persona)
                .FirstOrDefaultAsync(p => p.IdProveedor == id);

            if (proveedor == null)
            {
                return NotFound();
            }

            proveedor.Estatus = proveedorUpdateDto.Estatus;

            if (proveedorUpdateDto.Persona != null)
            {
                proveedor.Persona.Nombre = proveedorUpdateDto.Persona.Nombre;
                proveedor.Persona.ApellidoPaterno = proveedorUpdateDto.Persona.ApellidoPaterno;
                proveedor.Persona.ApellidoMaterno = proveedorUpdateDto.Persona.ApellidoMaterno;
                proveedor.Persona.Telefono = proveedorUpdateDto.Persona.Telefono;
                proveedor.Persona.Direccion = proveedorUpdateDto.Persona.Direccion;
                proveedor.Persona.Email = proveedorUpdateDto.Persona.Email;
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProveedorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Proveedores/id
        [HttpDelete]
        [Route("EliminarProveedor/{id:int}")]
        public async Task<IActionResult> DeleteProveedor(int id)
        {
            var proveedor = await _context.Proveedores.FindAsync(id);
            if (proveedor == null)
            {
                return NotFound();
            }

            _context.Proveedores.Remove(proveedor);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ProveedorExists(int id)
        {
            return _context.Proveedores.Any(e => e.IdProveedor == id);
        }
    }
}