﻿using Lignaris.DTO;
using Lignaris.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class MateriaPrimasController : ControllerBase
{
    private readonly AppDbContext _context;

    public MateriaPrimasController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    [Route("ListaMateriaPrima")]
    public async Task<ActionResult<IEnumerable<MateriaPrima>>> GetMateriaPrimas()
    {
        return await _context.MateriasPrimas.Include(m => m.Proveedor).ToListAsync();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<MateriaPrima>> GetMateriaPrima(int id)
    {
        var materiaPrima = await _context.MateriasPrimas.Include(m => m.Proveedor).FirstOrDefaultAsync(m => m.IdMateriaPrima == id);
        if (materiaPrima == null)
        {
            return NotFound();
        }
        return materiaPrima;
    }

    [HttpPost]
    [Route("{idProveedor}/AgregarMateriaPrima")]
    public async Task<ActionResult> PostMateriaPrima(int idProveedor, List<MateriaPrimaDTO> materiaPrimaDTOs)
    {
        var proveedor = await _context.Proveedores.FindAsync(idProveedor);
        if (proveedor == null)
        {
            return NotFound();
        }

        foreach (var materiaPrimaDTO in materiaPrimaDTOs)
        {
            var materiaPrima = new MateriaPrima
            {
                Nombre = materiaPrimaDTO.Nombre,
                TipoMedida = materiaPrimaDTO.TipoMedida,
                CantidadMinima = materiaPrimaDTO.CantidadMinima,
                IdProveedor = idProveedor
            };

            _context.MateriasPrimas.Add(materiaPrima);
        }

        await _context.SaveChangesAsync();
        return NoContent();
    }


    [HttpPut]
    [Route("ModificarMateriaPrima/{id:int}")]
    public async Task<IActionResult> PutMateriaPrima(int id, MateriaPrima materiaPrima)
    {
        if (id != materiaPrima.IdMateriaPrima)
        {
            return BadRequest();
        }

        _context.Entry(materiaPrima).State = EntityState.Modified;
        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!MateriaPrimaExists(id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    [HttpDelete]
    [Route("EliminarMateriaPrima/{id:int}")]
    public async Task<IActionResult> DeleteMateriaPrima(int id)
    {
        var materiaPrima = await _context.MateriasPrimas.FindAsync(id);
        if (materiaPrima == null)
        {
            return NotFound();
        }

        _context.MateriasPrimas.Remove(materiaPrima);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool MateriaPrimaExists(int id)
    {
        return _context.MateriasPrimas.Any(e => e.IdMateriaPrima == id);
    }
}
